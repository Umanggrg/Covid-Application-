package com.example.covidapp;

public interface RecyclerItemClick {
    void onClickItem(int position);
}
